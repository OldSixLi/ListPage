$(function() {

  $(document).pjax("a", "#workspace", {
    timeout: 10000
  });
  $(document).on('pjax:send', function() { //pjax链接点击后显示加载动画；
    $(".loaders").css("display", "block");
    // alert("PJAX开始!");
    console.log("");
  });

  $("dd ").each(function() {
    $(this).click(function() {
      var href = $(this).attr("data-link ");
      $("#work-frame ").attr("src ", href);
    });
  });
});